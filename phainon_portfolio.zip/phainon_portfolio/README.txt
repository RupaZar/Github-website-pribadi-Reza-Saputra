PH AINON-INSPIRED PORTFOLIO
===========================

CARA MENJALANKAN
1. Ekstrak file ZIP ini.
2. Buka folder phainon_portfolio di Visual Studio Code.
3. Buka index.html di browser, atau gunakan ekstensi Live Server.

FILE
- index.html : struktur halaman website
- style.css  : desain, warna, layout, dan animasi CSS
- script.js  : interaksi dan efek JavaScript

SEBELUM DIPAKAI
Cari dan ganti teks placeholder berikut di index.html:
- "Your Name" / "YN"
- "Nama Universitas", jurusan, sekolah, dan pengalaman
- Nomor WhatsApp pada tautan https://wa.me/6281234567890
- "username" pada tautan Instagram dan GitHub
Nomor WhatsApp harus memakai kode negara tanpa tanda +, spasi, atau angka 0 di depan.
Contoh: nomor Indonesia 081234567890 menjadi 6281234567890.

CATATAN
Google Fonts memerlukan koneksi internet. Website tetap berjalan tanpa font eksternal,
tetapi font akan memakai fallback jika koneksi tidak tersedia.
